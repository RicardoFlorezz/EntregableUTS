import javax.swing.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Login extends JFrame {
    private JTextField txtUsuario;
    private JPasswordField txtContraseña;  // Usar JPasswordField para ocultar la contraseña
    private JButton btnRegistrar;
    private JButton btnCerrar;
    private JButton btnIngresar;
    private JPanel panel;

    public static void main(String[] args) {
        Login log = new Login();
    }

    public Login() {
        // Configuración de la ventana principal
        setContentPane(panel);
        this.setLocationRelativeTo(null);
        setTitle("Banco DUTS");
        setSize(500, 300);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);

        // Acción para el botón Ingresar
        btnIngresar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usuario = txtUsuario.getText();
                String contraseña = new String(txtContraseña.getPassword());  // Usar la contraseña correctamente

                // Validar usuario y contraseña
                try (BufferedReader reader = new BufferedReader(new FileReader("usuarios.txt"))) {
                    String line;
                    boolean autenticado = false;

                    while ((line = reader.readLine()) != null) {
                        String[] datos = line.split(",");
                        String usuarioGuardado = datos[2];  //  el nombre de usuario está en la tercera posición
                        String contraseñaGuardada = datos[4]; // La contraseña está en la quinta posición

                        if (usuario.equals(usuarioGuardado) && contraseña.equals(contraseñaGuardada)) {
                            autenticado = true;
                            break;
                        }
                    }

                    if (autenticado) {
                        // Si el usuario es autenticado, guardamos el usuario logueado en la clase Usuario
                        Usuario.usuarioLogueado = usuario;  // Guardamos el usuario logueado en la variable estática

                        JOptionPane.showMessageDialog(null, "Bienvenido " + usuario);
                        // Abrir VerPerfil
                        Menu menuPrincipal = new Menu();
                        menuPrincipal.setVisible(true);
                        dispose(); // Cierra la ventana de login
                    } else {
                        JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos.");
                    }
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(null, "Error al leer el archivo de usuarios.");
                }
            }
        });




        btnRegistrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Abre la ventana de registro
                Registro registro = new Registro();
                registro.setVisible(true);
                dispose();  // Cierra la ventana de login
            }
        });


        btnCerrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);  // Cierra la aplicación
            }
        });
    }
}


