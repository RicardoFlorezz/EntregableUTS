public class Usuario {
    public static String usuarioLogueado = "";
}
