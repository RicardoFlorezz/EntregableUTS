import java.io.*;

public class UsuariosGuardados {
    // Guardar un nuevo usuario en el archivo
    public static void registrarUsuario(String usuario, String contraseña) {
        try (FileWriter fw = new FileWriter("usuarios.txt", true);
             BufferedWriter bw = new BufferedWriter(fw)) {

            bw.write(usuario + "," + contraseña);  // Guardamos el usuario y la contraseña separados por una coma
            bw.newLine();  // Añadimos una nueva línea para cada nuevo usuario

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Verificar si el usuario ya existe
    public static boolean verificarUsuario(String usuario, String contraseña) {
        try (BufferedReader br = new BufferedReader(new FileReader("usuarios.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] datos = line.split(",");
                if (datos[0].equals(usuario) && datos[1].equals(contraseña)) {
                    return true;  // Usuario y contraseña coinciden
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }
}

