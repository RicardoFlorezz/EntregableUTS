import javax.swing.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Registro extends JFrame {
    private JTextField txtNombre;
    private JTextField txtApellido;
    private JTextField txtUsuario;
    private JTextField txtEmail;
    private JButton btncrear;
    private JPanel panelRegistro;
    private JPasswordField txtContraseña;  // Cambié el nombre de la variable para ajustarme al nombre usado en el código

    public static void main(String[] args) {
        // Llamamos al constructor para mostrar la ventana
        Registro registro = new Registro();
    }

    public Registro() {
        // Configuración de la ventana de registro
        setContentPane(panelRegistro);
        this.setLocationRelativeTo(null);
        setTitle("Registro");
        setSize(300, 300);
        setVisible(true);

        // Acción cuando se presiona el botón de "Crear"
        btncrear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obtener los datos ingresados por el usuario
                String nombre = txtNombre.getText();
                String apellido = txtApellido.getText();
                String usuario = txtUsuario.getText();
                String email = txtEmail.getText();

                // Obtener la contraseña como arreglo de caracteres y luego convertirla en String
                char[] contraseñaArray = txtContraseña.getPassword();
                String contraseña = new String(contraseñaArray);

                // Verificar que todos los campos estén completos
                if (nombre.isEmpty() || apellido.isEmpty() || usuario.isEmpty() || email.isEmpty() || contraseña.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Por favor complete todos los campos.");
                } else {
                    // Si todos los campos están completos, guardamos la información en un archivo

                    try (BufferedWriter writer = new BufferedWriter(new FileWriter("usuarios.txt", true))) {
                        // Guardamos los datos del usuario en el archivo separados por coma
                        writer.write(nombre + "," + apellido + "," + usuario + "," + email + "," + contraseña);
                        writer.newLine();  // Nueva línea para cada nuevo usuario

                        // Mostrar mensaje de éxito
                        JOptionPane.showMessageDialog(null, "Registro Exitoso");

                        // Cerrar la ventana de registro y abrir el login
                        dispose();
                        Login login = new Login();
                        login.setVisible(true);
                    } catch (IOException ex) {
                        // En caso de error al guardar en el archivo
                        JOptionPane.showMessageDialog(null, "Error al guardar los datos.");
                        ex.printStackTrace();
                    }
                }
            }
        });
    }
}
