import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EnviarDUTS extends JFrame {
    private JTextField txtCorreo;
    private JPasswordField passContra;
    private JButton btnCerrar;
    private JPanel panelEnviarDUTS;
    private JButton btnEnviar;
    private JTextField txtMonto;

    public static void main(String[] args) {
        EnviarDUTS enviarDUTS = new EnviarDUTS();
    }

    public EnviarDUTS() {
        setContentPane(panelEnviarDUTS);
        setTitle("Enviar DUTS");
        setSize(400, 300);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);  // Esto cierra solo esta ventana, no la app completa
        setLocationRelativeTo(null); // Centra la ventana
        setVisible(true);

        btnCerrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Menu menu = new Menu();// Volver al menú sin crear una nueva instancia, solo cerrando la ventana actual
                dispose();  // Esto cierra la ventana actual (EnviarDUTS)
            }
        });

        btnEnviar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String correo = txtCorreo.getText();
                String monto = txtMonto.getText();



                if (correo.isEmpty() || monto.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos.");
                    return;
                }


                JOptionPane.showMessageDialog(null, "Enviando el monto de " + monto + " al correo: " + correo + "...");


                JOptionPane.showMessageDialog(null, "¡Se ha enviado con éxito!");

                txtCorreo.setText("");
                passContra.setText("");
                txtMonto.setText("");

            }

        });
    }
}
