import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ConsultarSaldo extends JFrame{
    private JPanel panelConsultarSaldo;
    private JButton btnCerrar;

    public static void main(String[] args) {
        ConsultarSaldo consultarSaldo = new ConsultarSaldo();

    }

    public ConsultarSaldo () {
        setContentPane(panelConsultarSaldo);
        this.setLocationRelativeTo(null);
        setTitle("Saldo");
        setSize(500, 500);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);

        btnCerrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Menu menuprincipal = new Menu();
                dispose();
            }
        });
    }

}
