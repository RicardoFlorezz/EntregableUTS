import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class VerPerfil extends JFrame {
    private JTextField txtNombre;
    private JTextField txtApellido;
    private JTextField txtEmail;
    private JPanel panelPerfil;
    private JButton btnCerrar;

    private final String archivoUsuarios = "usuarios.txt";

    // Constructor para recibir el usuario logueado
    public VerPerfil(String usuarioLogueado) {
        setContentPane(panelPerfil);
        setTitle("Ver Perfil");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Cargar los datos del perfil desde el archivo
        cargarPerfil(usuarioLogueado);


        btnCerrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Menu menuprincipal = new Menu();
                dispose();

            }
        });
    }

    // Método para cargar el perfil
    private void cargarPerfil(String usuarioLogueado) {
        try (BufferedReader reader = new BufferedReader(new FileReader(archivoUsuarios))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] userData = line.split(",");
                if (userData[2].equals(usuarioLogueado)) {  // Verificar si el usuario logueado coincide
                    txtNombre.setText(userData[0]);
                    txtApellido.setText(userData[1]);
                    txtEmail.setText(userData[3]);
                    break;
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    // Método para guardar cambios en el perfil
    private void guardarPerfil(String usuarioLogueado) {
        // Aquí puedes agregar la lógica para guardar los cambios en el archivo
    }
}







