import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Analisis extends JFrame{
    private JButton DUTSPromedioPorSemanaButton;
    private JButton DUTSPromedioPorMesButton;
    private JButton DUTSPromedioPorAñoButton;
    private JButton DUTSPromedioPorSemestreButton;
    private JButton cerrarButton;
    private JPanel panelAnalisis;

    public static void main(String[] args) {
        Analisis analisis = new Analisis();
    }


    public Analisis() {
        setContentPane(panelAnalisis);
        this.setLocationRelativeTo(null);
        setTitle("Analisis Financiero");
        setSize(500, 500);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);




        DUTSPromedioPorSemanaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,"Aun no sabemos de ti!");

            }
        });


        DUTSPromedioPorMesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,"Aun no sabemos de ti!");

            }
        });


        DUTSPromedioPorAñoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,"Aun no sabemos de ti!");

            }
        });


        DUTSPromedioPorSemestreButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,"Aun no sabemos de ti!");

            }
        });


        cerrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Menu menu = new Menu();
                dispose();
            }
        });
    }
}
