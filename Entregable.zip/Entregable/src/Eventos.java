import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class Eventos extends JFrame {
    private JButton eventosDisponiblesButton;
    private JButton comoConseguirDUTSButton;
    private JButton registrarseButton;
    private JButton darseDeBajaButton;
    private JButton btnEventosRegistrados;  // Nuevo botón
    private JButton cerrarButton;
    private JPanel panelEventos;


    private List<String> usuariosRegistrados = new ArrayList<>();

    public static void main(String[] args) {
        Eventos eventos = new Eventos();
    }

    public Eventos() {
        setContentPane(panelEventos);
        this.setLocationRelativeTo(null);
        setTitle("Eventos");
        setSize(400, 300);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);


        eventosDisponiblesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "En este momento hay evento activo en la universidad");
            }
        });


        comoConseguirDUTSButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Puedes conseguirlo depositando o participando en los distintos eventos de la universidad");
            }
        });


        registrarseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usuario = JOptionPane.showInputDialog("Ingresa tu nombre para registrarte en el evento:");
                if (usuario != null && !usuario.isEmpty()) {
                    // Si el usuario no está ya registrado, agregarlo
                    if (!usuariosRegistrados.contains(usuario)) {
                        usuariosRegistrados.add(usuario);
                        JOptionPane.showMessageDialog(null, usuario + " se ha registrado correctamente en el evento.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Ya estás registrado en este evento.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor ingresa un nombre válido.");
                }
            }
        });


        darseDeBajaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usuario = JOptionPane.showInputDialog("Ingresa tu nombre para darte de baja del evento:");
                if (usuario != null && !usuario.isEmpty()) {
                    // Si el usuario está registrado, eliminarlo
                    if (usuariosRegistrados.contains(usuario)) {
                        usuariosRegistrados.remove(usuario);
                        JOptionPane.showMessageDialog(null, usuario + " se ha dado de baja correctamente.");
                    } else {
                        JOptionPane.showMessageDialog(null, "No estás registrado en este evento.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor ingresa un nombre válido.");
                }
            }
        });


        btnEventosRegistrados.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usuario = JOptionPane.showInputDialog("Ingresa tu nombre para verificar si estás registrado en el evento:");
                if (usuario != null && !usuario.isEmpty()) {
                    // Verificar si el usuario está registrado
                    if (usuariosRegistrados.contains(usuario)) {
                        JOptionPane.showMessageDialog(null, usuario + " está registrado en el evento.");
                    } else {
                        JOptionPane.showMessageDialog(null, "No estás registrado en este evento.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor ingresa un nombre válido.");
                }
            }
        });

        // Acción para cerrar el evento
        cerrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Menu menu = new Menu();
                dispose();
            }
        });
    }
}