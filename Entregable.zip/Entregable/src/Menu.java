import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Menu extends JFrame {
    private JButton btnVerPerfil;
    private JButton btnConsultarSaldo;
    private JButton btnEnviarDUTS;
    private JButton btnAnalisisFinanciero;
    private JButton btnEventos;
    private JButton btnCerrarSesion;
    private JPanel panelMenu;

    public static void main(String[] args) {
        Menu menu = new Menu();
    }

    public Menu () {
        // Configurar la ventana
        setContentPane(panelMenu);
        this.setLocationRelativeTo(null);
        setTitle("Banco DUTS");
        setSize(500, 500);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);

        // Acción al cerrar sesión
        btnCerrarSesion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Login principal = new Login();
                principal.setVisible(true);
                dispose();
            }
        });

        // Acción al hacer clic en "Ver Perfil"
        btnVerPerfil.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obtener el usuario logueado desde la clase Usuario
                String usuarioLogueado = Usuario.usuarioLogueado;  // Acceder a la variable estática

                // Crear la instancia de VerPerfil y pasarle el usuario logueado
                VerPerfil verPerfil = new VerPerfil(usuarioLogueado);  // Pasa el usuario logueado
                verPerfil.setVisible(true);// Mostrar la ventana
                dispose();
            }
        });
        btnConsultarSaldo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ConsultarSaldo consultarSaldo = new ConsultarSaldo();
                consultarSaldo.setVisible(true);
                dispose();
            }
        });
        btnEnviarDUTS.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                EnviarDUTS enviarDUTS = new EnviarDUTS();
                enviarDUTS.setVisible(true);
                dispose();
            }
        });
        btnAnalisisFinanciero.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Analisis analisis = new Analisis();
                analisis.setVisible(true);
                dispose();
            }
        });


        btnEventos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Eventos eventos = new Eventos();
                eventos.setVisible(true);
                dispose();
            }
        });
    }
}

